KAngel

A retro RPG-style pixel-art pet inspired by KAngel from NEEDY GIRL OVERDOSE.

Install in ChatGPT Work

1. Attach this ZIP to a ChatGPT Work conversation with Pets available.
2. Send this request.
   Use Pets to create a custom pet named KAngel from kangel-spritesheet.png in this ZIP, then select it as my active pet.
3. If the chat cannot open the ZIP, extract it and attach kangel-spritesheet.png directly with the same request.

Files

kangel-spritesheet.png — the original sprite sheet exported from Pets, v2, 1536 × 2288 pixels.
kangel-idle-preview.gif — a looping idle animation rendered from the existing sprite sheet.
README.txt — these setup instructions.
