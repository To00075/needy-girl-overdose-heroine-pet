NEEDY GIRL OVERDOSE Heroine Pet

A fan-made pixel-art pet for ChatGPT Work based on the heroine of NEEDY GIRL OVERDOSE.

Install in ChatGPT Work

1. Attach this ZIP to a ChatGPT Work conversation with Pets available.
2. Send this request.
   Use Pets to create a custom pet named NEEDY GIRL OVERDOSE Heroine from heroine-spritesheet.png in this ZIP, then select it as my active pet.
3. If the chat cannot open the ZIP, extract it and attach heroine-spritesheet.png directly with the same request.

Files

heroine-spritesheet.png — original v2 pet sprite sheet exported from Pets.
heroine-idle-preview.gif — looping idle animation.
README.txt — these installation instructions.
